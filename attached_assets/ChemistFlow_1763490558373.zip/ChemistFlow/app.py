import streamlit as st
import pandas as pd
import streamlit as st
import pandas as pd
from datetime import datetime, date
import plotly.express as px
import plotly.graph_objects as go
from streamlit_option_menu import option_menu
import json
import os
from database import Database
import cohere
from dotenv import load_dotenv  # ← ADD THIS LINE

# Load environment variables from .env file
load_dotenv()  # ← ADD THIS LINE
from datetime import datetime, date
import plotly.express as px
import plotly.graph_objects as go
from streamlit_option_menu import option_menu
import json
import os
from database import Database
import cohere

try:
    import cv2
    from pyzbar import pyzbar
    BARCODE_AVAILABLE = True
except ImportError:
    BARCODE_AVAILABLE = False

st.set_page_config(
    page_title="Pharmacy Management System",
    page_icon="💊",
    layout="wide",
    initial_sidebar_state="expanded"
)

db = Database()

if 'user' not in st.session_state:
    st.session_state.user = None
if 'pharmacy_name' not in st.session_state:
    st.session_state.pharmacy_name = db.get_pharmacy_name()
if 'cart' not in st.session_state:
    st.session_state.cart = []

def init_cohere():
    api_key = os.getenv('COHERE_API_KEY')
    if api_key:
        return cohere.Client(api_key)
    return None

def get_ai_response(question, context=""):
    try:
        co = init_cohere()
        if not co:
            return "AI chat is not configured. Please add your COHERE_API_KEY to environment variables."
        
        prompt = f"""You are a helpful pharmacy assistant for {st.session_state.pharmacy_name or 'our pharmacy'}. 
        You help customers with medication questions, health advice, and general pharmacy inquiries.
        
        Context: {context}
        
        Customer Question: {question}
        
        Please provide a helpful, professional response:"""
        
        response = co.generate(
            prompt=prompt,
            max_tokens=300,
            temperature=0.7
        )
        return response.generations[0].text.strip()
    except Exception as e:
        return f"I apologize, but I'm having trouble processing your request right now. Please try again or contact our staff directly."

def landing_page():
    pharmacy_name = st.session_state.pharmacy_name or "PharmaCare Kenya"
    
    st.markdown(f"""
        <style>
        .hero-section {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 3rem 2rem;
            border-radius: 15px;
            color: white;
            text-align: center;
            margin-bottom: 2rem;
        }}
        .hero-title {{
            font-size: 3rem;
            font-weight: 800;
            margin-bottom: 1rem;
        }}
        .hero-subtitle {{
            font-size: 1.3rem;
            margin-bottom: 2rem;
            opacity: 0.95;
        }}
        .feature-card {{
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            text-align: center;
            height: 100%;
        }}
        .feature-icon {{
            font-size: 3rem;
            margin-bottom: 1rem;
        }}
        .cta-button {{
            background: #667eea;
            color: white;
            padding: 1rem 2rem;
            border-radius: 8px;
            font-size: 1.2rem;
            font-weight: 600;
            border: none;
            cursor: pointer;
            margin: 0.5rem;
        }}
        .stats-box {{
            background: #f8f9fa;
            padding: 1.5rem;
            border-radius: 10px;
            border-left: 4px solid #667eea;
        }}
        </style>
    """, unsafe_allow_html=True)
    
    st.markdown(f"""
        <div class="hero-section">
            <div class="hero-title">💊 {pharmacy_name}</div>
            <div class="hero-subtitle">Your Trusted Partner in Health & Wellness</div>
            <p style="font-size: 1.1rem;">Modern Pharmacy Management System - Serving Kenya with Care</p>
        </div>
    """, unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
            <div class="feature-card">
                <div class="feature-icon">🏥</div>
                <h3>Quality Medicines</h3>
                <p>Authentic pharmaceutical products from trusted suppliers, ensuring your health and safety</p>
            </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
            <div class="feature-card">
                <div class="feature-icon">💳</div>
                <h3>Flexible Payment</h3>
                <p>Cash, M-Pesa, Bank Transfer, or Credit options available for your convenience</p>
            </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
            <div class="feature-card">
                <div class="feature-icon">🤖</div>
                <h3>AI Assistant</h3>
                <p>24/7 AI-powered support to answer your medication and health questions</p>
            </div>
        """, unsafe_allow_html=True)
    
    st.markdown("<br>", unsafe_allow_html=True)
    
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.markdown("""
            <div class="stats-box">
                <h2 style="color: #667eea; margin:0;">1000+</h2>
                <p style="margin:0;">Products Available</p>
            </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
            <div class="stats-box">
                <h2 style="color: #667eea; margin:0;">24/7</h2>
                <p style="margin:0;">Customer Support</p>
            </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
            <div class="stats-box">
                <h2 style="color: #667eea; margin:0;">100%</h2>
                <p style="margin:0;">Authentic Products</p>
            </div>
        """, unsafe_allow_html=True)
    
    with col4:
        st.markdown("""
            <div class="stats-box">
                <h2 style="color: #667eea; margin:0;">Fast</h2>
                <p style="margin:0;">Service Delivery</p>
            </div>
        """, unsafe_allow_html=True)
    
    st.markdown("<br>", unsafe_allow_html=True)
    
    st.markdown("### 🚀 Get Started Today")
    col1, col2, col3 = st.columns([1,1,1])
    
    with col1:
        if st.button("👤 Customer Login/Register", use_container_width=True):
            st.session_state.page = 'login'
            st.rerun()
    
    with col2:
        if st.button("👨‍⚕️ Employee Login", use_container_width=True):
            st.session_state.page = 'login'
            st.rerun()
    
    with col3:
        if st.button("🔐 Admin Login", use_container_width=True):
            st.session_state.page = 'login'
            st.rerun()
    
    st.markdown("<br>", unsafe_allow_html=True)
    
    with st.expander("ℹ️ About Our Services"):
        st.markdown("""
        #### Our Commitment to You
        
        - **Prescription Medications**: Wide range of prescription drugs with proper documentation
        - **Over-the-Counter Products**: Health supplements, vitamins, and general wellness products
        - **Expert Consultation**: Professional pharmacists available for medication guidance
        - **Credit Facility**: Buy now, pay later options for registered customers
        - **Inventory Tracking**: Always know what's in stock with our real-time system
        - **Secure Payments**: Multiple payment options including M-Pesa integration
        
        #### Why Choose Us?
        
        ✓ Licensed and certified pharmacy operating under Kenyan regulations  
        ✓ Competitive pricing with flexible payment options  
        ✓ Professional and friendly staff  
        ✓ Clean and modern facilities  
        ✓ Quick service and delivery  
        """)

def login_page():
    st.title("🔐 Login")
    
    tab1, tab2 = st.tabs(["Login", "Register"])
    
    with tab1:
        st.subheader("Sign In")
        username = st.text_input("Username", key="login_username")
        password = st.text_input("Password", type="password", key="login_password")
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("Login", use_container_width=True):
                if username and password:
                    user, error = db.authenticate_user(username, password)
                    if user:
                        st.session_state.user = user
                        st.success(f"Welcome back, {user['full_name']}!")
                        st.rerun()
                    else:
                        st.error(error)
                else:
                    st.warning("Please enter both username and password")
        
        with col2:
            if st.button("Back to Home", use_container_width=True):
                st.session_state.page = 'landing'
                st.rerun()
    
    with tab2:
        st.subheader("Create Account")
        role = st.selectbox("Register as", ["Customer", "Employee"])
        
        if role == "Employee" and st.session_state.pharmacy_name:
            st.info(f"Registering as employee for: **{st.session_state.pharmacy_name}**")
        
        full_name = st.text_input("Full Name", key="reg_fullname")
        username = st.text_input("Username", key="reg_username")
        email = st.text_input("Email", key="reg_email")
        phone = st.text_input("Phone Number", key="reg_phone")
        password = st.text_input("Password", type="password", key="reg_password")
        confirm_password = st.text_input("Confirm Password", type="password", key="reg_confirm")
        
        if st.button("Register", use_container_width=True):
            if not all([full_name, username, phone, password]):
                st.warning("Please fill in all required fields")
            elif password != confirm_password:
                st.error("Passwords do not match!")
            elif len(password) < 6:
                st.error("Password must be at least 6 characters long")
            else:
                role_db = 'customer' if role == "Customer" else 'employee'
                success, message = db.create_user(username, password, full_name, email, phone, role_db)
                if success:
                    st.success(message)
                    if role_db == 'employee':
                        st.info("Your account will be activated once the admin approves it.")
                else:
                    st.error(message)

def admin_dashboard():
    st.title(f"🏥 {st.session_state.pharmacy_name or 'Admin Dashboard'}")
    
    selected = option_menu(
        menu_title=None,
        options=["Dashboard", "Pharmacy Settings", "Approve Users", "Inventory", "Sales", "Customers", "CRM", "Pending Actions", "Reports", "AI Chat"],
        icons=["speedometer2", "gear", "person-check", "box-seam", "cart", "people", "chat-dots", "bell", "graph-up", "robot"],
        menu_icon="cast",
        default_index=0,
        orientation="horizontal"
    )
    
    if selected == "Dashboard":
        show_admin_dashboard_overview()
    elif selected == "Pharmacy Settings":
        show_pharmacy_settings()
    elif selected == "Approve Users":
        show_approve_users()
    elif selected == "Inventory":
        show_inventory_management()
    elif selected == "Sales":
        show_sales_module()
    elif selected == "Customers":
        show_customer_management()
    elif selected == "CRM":
        show_crm_module()
    elif selected == "Pending Actions":
        show_pending_actions()
    elif selected == "Reports":
        show_reports()
    elif selected == "AI Chat":
        show_admin_chat()

def show_admin_dashboard_overview():
    st.subheader("📊 Dashboard Overview")
    
    col1, col2, col3, col4 = st.columns(4)
    
    sales_summary = db.get_sales_summary()
    low_stock = db.get_low_stock_items()
    pending_users = db.get_pending_users()
    pending_actions = db.get_pending_actions()
    
    with col1:
        st.metric("Total Sales", f"KES {sales_summary['total']:,.2f}" if sales_summary['total'] else "KES 0.00")
    
    with col2:
        st.metric("Low Stock Items", len(low_stock))
    
    with col3:
        st.metric("Pending Approvals", len(pending_users))
    
    with col4:
        st.metric("Pending Actions", len(pending_actions))
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("⚠️ Low Stock Alerts")
        if low_stock:
            for item in low_stock[:5]:
                st.warning(f"{item['name']}: {item['quantity']} units (Reorder at {item['reorder_level']})")
        else:
            st.success("All items are adequately stocked!")
    
    with col2:
        st.subheader("🔔 Recent Notifications")
        if pending_users:
            st.info(f"{len(pending_users)} user(s) waiting for approval")
        if pending_actions:
            st.info(f"{len(pending_actions)} action(s) waiting for review")
        if not pending_users and not pending_actions:
            st.success("No pending notifications")

def show_pharmacy_settings():
    st.subheader("⚙️ Pharmacy Settings")
    
    current_name = st.session_state.pharmacy_name
    
    st.write("**Current Pharmacy Name:**", current_name or "Not Set")
    
    new_name = st.text_input("Pharmacy Name", value=current_name or "", placeholder="e.g., Nibel Chemist")
    
    if st.button("Update Pharmacy Name"):
        if new_name:
            db.set_pharmacy_name(new_name)
            st.session_state.pharmacy_name = new_name
            st.success("Pharmacy name updated successfully!")
            st.rerun()
        else:
            st.warning("Please enter a pharmacy name")

def show_approve_users():
    st.subheader("👥 Approve Users")
    
    pending_users = db.get_pending_users()
    
    if not pending_users:
        st.info("No pending user approvals")
        return
    
    for user in pending_users:
        with st.expander(f"{user['full_name']} - {user['role'].title()} ({user['username']})"):
            col1, col2 = st.columns(2)
            with col1:
                st.write(f"**Email:** {user['email']}")
                st.write(f"**Phone:** {user['phone']}")
            with col2:
                st.write(f"**Registered:** {user['created_at']}")
                st.write(f"**Status:** {user['status']}")
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button(f"✅ Approve", key=f"approve_{user['id']}"):
                    db.approve_user(user['id'])
                    st.success(f"Approved {user['full_name']}")
                    st.rerun()
            with col2:
                if st.button(f"❌ Reject", key=f"reject_{user['id']}"):
                    db.reject_user(user['id'])
                    st.warning(f"Rejected {user['full_name']}")
                    st.rerun()

def show_inventory_management():
    st.subheader("📦 Inventory Management")
    
    tab1, tab2, tab3 = st.tabs(["View Inventory", "Add Item", "Scan Barcode"])
    
    with tab1:
        search_term = st.text_input("🔍 Search products (type to search)...", key="inventory_search")
        
        if search_term:
            items = db.search_inventory(search_term)
        else:
            items = db.get_all_inventory()
        
        if items:
            df = pd.DataFrame(items)
            df['unit_price'] = df['unit_price'].apply(lambda x: f"KES {x:,.2f}")
            st.dataframe(df[['barcode', 'name', 'category', 'quantity', 'unit_price', 'reorder_level', 'supplier']], use_container_width=True)
        else:
            st.info("No items found")
    
    with tab2:
        col1, col2 = st.columns(2)
        with col1:
            barcode = st.text_input("Barcode")
            name = st.text_input("Product Name *")
            category = st.selectbox("Category", ["Prescription", "OTC", "Supplements", "Medical Devices", "Other"])
            quantity = st.number_input("Quantity *", min_value=0, value=0)
        
        with col2:
            unit_price = st.number_input("Unit Price (KES) *", min_value=0.0, value=0.0, format="%.2f")
            reorder_level = st.number_input("Reorder Level", min_value=0, value=10)
            supplier = st.text_input("Supplier")
            expiry_date = st.date_input("Expiry Date", value=None)
        
        description = st.text_area("Description")
        
        if st.button("Add Item"):
            if name and unit_price > 0:
                success, message = db.add_inventory_item(
                    barcode, name, description, category, quantity, unit_price,
                    reorder_level, supplier, expiry_date.isoformat() if expiry_date else None,
                    st.session_state.user['id'], st.session_state.user['role']
                )
                if success:
                    st.success(message)
                    st.rerun()
                else:
                    st.error(message)
            else:
                st.warning("Please fill in required fields")
    
    with tab3:
        st.write("**Scan Barcode from Camera**")
        
        if not BARCODE_AVAILABLE:
            st.warning("📸 Barcode scanning feature requires additional system libraries. Use manual entry for now.")
            st.info("To enable barcode scanning, install the zbar system package and restart the application.")
        else:
            st.info("📱 For mobile: Use your phone camera to scan barcodes")
            st.info("💻 For computer: Click 'Take Photo' to use webcam")
            
            camera_image = st.camera_input("Scan barcode")
            
            if camera_image:
                import numpy as np
                from PIL import Image
                
                image = Image.open(camera_image)
                img_array = np.array(image)
                
                gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
                barcodes = pyzbar.decode(gray)
                
                if barcodes:
                    for barcode_obj in barcodes:
                        barcode_data = barcode_obj.data.decode('utf-8')
                        st.success(f"Barcode detected: {barcode_data}")
                        
                        item = db.get_inventory_by_barcode(barcode_data)
                        if item:
                            st.write("**Product Found:**")
                            st.write(f"Name: {item['name']}")
                            st.write(f"Price: KES {item['unit_price']:,.2f}")
                            st.write(f"Stock: {item['quantity']} units")
                        else:
                            st.warning("Product not found in inventory")
                else:
                    st.warning("No barcode detected. Please try again with better lighting.")

def show_sales_module():
    st.subheader("🛒 Sales Module")
    
    tab1, tab2 = st.tabs(["New Sale", "Sales History"])
    
    with tab1:
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.write("**Search & Add Products**")
            search = st.text_input("Search product name or barcode...", key="sales_search")
            
            if search:
                items = db.search_inventory(search)
                if items:
                    for item in items[:5]:
                        col_a, col_b, col_c = st.columns([3, 1, 1])
                        with col_a:
                            st.write(f"**{item['name']}** - KES {item['unit_price']:,.2f} ({item['quantity']} in stock)")
                        with col_b:
                            qty = st.number_input("Qty", min_value=1, max_value=item['quantity'], value=1, key=f"qty_{item['id']}")
                        with col_c:
                            if st.button("Add", key=f"add_{item['id']}"):
                                cart_item = {
                                    'id': item['id'],
                                    'name': item['name'],
                                    'unit_price': item['unit_price'],
                                    'quantity': qty,
                                    'total': item['unit_price'] * qty
                                }
                                st.session_state.cart.append(cart_item)
                                st.rerun()
        
        with col2:
            st.write("**Cart**")
            if st.session_state.cart:
                total = 0
                for idx, item in enumerate(st.session_state.cart):
                    st.write(f"{item['name']} x{item['quantity']}")
                    st.write(f"KES {item['total']:,.2f}")
                    if st.button("Remove", key=f"remove_{idx}"):
                        st.session_state.cart.pop(idx)
                        st.rerun()
                    st.divider()
                    total += item['total']
                
                st.write(f"**Total: KES {total:,.2f}**")
                
                customers = db.get_all_customers()
                customer_options = ["Walk-in Customer"] + [f"{c['customer_code']} - {c['full_name']}" for c in customers]
                selected_customer = st.selectbox("Customer", customer_options)
                
                payment_method = st.selectbox("Payment Method", ["Cash", "M-Pesa", "Bank Transfer", "Credit"])
                amount_paid = st.number_input("Amount Paid (KES)", min_value=0.0, value=total, format="%.2f")
                
                if st.button("Complete Sale", use_container_width=True):
                    customer_id = None
                    if selected_customer != "Walk-in Customer":
                        customer_code = selected_customer.split(" - ")[0]
                        for c in customers:
                            if c['customer_code'] == customer_code:
                                customer_id = c['id']
                                break
                    
                    success, sale_number, sale_id = db.create_sale(
                        customer_id, st.session_state.cart, total, amount_paid,
                        payment_method, st.session_state.user['id']
                    )
                    
                    if success:
                        st.success(f"Sale completed! Sale Number: {sale_number}")
                        st.session_state.cart = []
                        st.rerun()
                    else:
                        st.error(f"Error: {sale_number}")
            else:
                st.info("Cart is empty")
    
    with tab2:
        sales = db.get_all_sales()
        if sales:
            df = pd.DataFrame(sales)
            df['total_amount'] = df['total_amount'].apply(lambda x: f"KES {x:,.2f}")
            df['amount_paid'] = df['amount_paid'].apply(lambda x: f"KES {x:,.2f}")
            st.dataframe(df[['sale_number', 'customer_name', 'total_amount', 'amount_paid', 'payment_method', 'status', 'created_at']], use_container_width=True)
        else:
            st.info("No sales recorded yet")

def show_customer_management():
    st.subheader("👥 Customer Management")
    
    customers = db.get_all_customers()
    
    if customers:
        for customer in customers:
            with st.expander(f"{customer['customer_code']} - {customer['full_name']}"):
                col1, col2 = st.columns(2)
                with col1:
                    st.write(f"**Phone:** {customer['phone']}")
                    st.write(f"**Email:** {customer['email']}")
                    st.write(f"**Address:** {customer['address']}")
                
                with col2:
                    st.write(f"**Credit Limit:** KES {customer['credit_limit']:,.2f}")
                    st.write(f"**Outstanding Balance:** KES {customer['outstanding_balance']:,.2f}")
                    st.write(f"**Joined:** {customer['created_at']}")
                
                customer_id = customer['id']
                if st.button(f"Record Payment", key=f"pay_{customer_id}"):
                    st.session_state[f'show_payment_{customer_id}'] = True
                
                if st.session_state.get(f'show_payment_{customer_id}', False):
                    amount = st.number_input("Payment Amount (KES)", min_value=0.0, key=f"amount_{customer_id}", format="%.2f")
                    payment_method = st.selectbox("Payment Method", ["Cash", "M-Pesa", "Bank Transfer"], key=f"method_{customer_id}")
                    
                    if st.button("Submit Payment", key=f"submit_{customer_id}"):
                        success, message = db.record_payment(
                            customer_id, None, amount, payment_method,
                            st.session_state.user['id']
                        )
                        if success:
                            st.success(message)
                            st.session_state[f'show_payment_{customer_id}'] = False
                            st.rerun()
                        else:
                            st.error(message)
    else:
        st.info("No customers registered yet")

def show_crm_module():
    st.subheader("💼 Customer Relationship Management")
    
    tab1, tab2 = st.tabs(["Complaints", "Customer Analytics"])
    
    with tab1:
        complaints = db.get_all_complaints()
        if complaints:
            for complaint in complaints:
                status_color = {"open": "🔴", "in_progress": "🟡", "resolved": "🟢", "closed": "⚫"}
                with st.expander(f"{status_color[complaint['status']]} {complaint['subject']} - {complaint['customer_name']}"):
                    st.write(f"**Customer:** {complaint['customer_name']} ({complaint['customer_code']})")
                    st.write(f"**Date:** {complaint['created_at']}")
                    st.write(f"**Message:** {complaint['message']}")
                    
                    if complaint['response']:
                        st.info(f"**Response:** {complaint['response']}")
                    
                    new_status = st.selectbox("Status", ["open", "in_progress", "resolved", "closed"],
                                            index=["open", "in_progress", "resolved", "closed"].index(complaint['status']),
                                            key=f"status_{complaint['id']}")
                    new_response = st.text_area("Response", value=complaint['response'] or "", key=f"response_{complaint['id']}")
                    
                    if st.button("Update", key=f"update_{complaint['id']}"):
                        db.update_complaint(complaint['id'], new_status, new_response)
                        st.success("Complaint updated!")
                        st.rerun()
        else:
            st.info("No complaints yet")
    
    with tab2:
        customers = db.get_all_customers()
        if customers:
            df = pd.DataFrame(customers)
            
            fig = px.bar(df.head(10), x='full_name', y='outstanding_balance',
                        title='Top 10 Customers by Outstanding Balance',
                        labels={'outstanding_balance': 'Balance (KES)', 'full_name': 'Customer'})
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No customer data available")

def show_pending_actions():
    st.subheader("🔔 Pending Actions - Employee Requests")
    
    actions = db.get_pending_actions()
    
    if not actions:
        st.info("No pending actions")
        return
    
    for action in actions:
        with st.expander(f"{action['action_type'].replace('_', ' ').title()} by {action['employee_name']}"):
            st.write(f"**Description:** {action['description']}")
            st.write(f"**Submitted:** {action['created_at']}")
            
            action_data = json.loads(action['action_data'])
            st.json(action_data)
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("✅ Approve", key=f"approve_action_{action['id']}"):
                    db.approve_action(action['id'], st.session_state.user['id'])
                    st.success("Action approved!")
                    st.rerun()
            
            with col2:
                action_id = action['id']
                if st.button("❌ Delete", key=f"delete_action_{action_id}"):
                    st.session_state[f'show_delete_confirm_{action_id}'] = True
            
            action_id = action['id']
            if st.session_state.get(f'show_delete_confirm_{action_id}', False):
                password = st.text_input("Enter your password to confirm deletion", type="password", key=f"del_pwd_{action_id}")
                if st.button("Confirm Delete", key=f"confirm_del_{action_id}"):
                    user, error = db.authenticate_user(st.session_state.user['username'], password)
                    if user:
                        db.reject_action(action_id, st.session_state.user['id'])
                        st.success("Action deleted!")
                        st.session_state[f'show_delete_confirm_{action_id}'] = False
                        st.rerun()
                    else:
                        st.error("Invalid password!")

def show_reports():
    st.subheader("📊 Reports & Analytics")
    
    tab1, tab2, tab3 = st.tabs(["Sales Report", "Inventory Report", "Customer Report"])
    
    with tab1:
        col1, col2 = st.columns(2)
        with col1:
            start_date = st.date_input("Start Date", value=date.today())
        with col2:
            end_date = st.date_input("End Date", value=date.today())
        
        summary = db.get_sales_summary(start_date, end_date)
        
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Total Sales", f"KES {summary['total']:,.2f}" if summary['total'] else "KES 0.00")
        with col2:
            st.metric("Number of Transactions", summary['count'] or 0)
        
        sales = db.get_all_sales()
        if sales:
            df = pd.DataFrame(sales)
            df['date'] = pd.to_datetime(df['created_at']).dt.date
            daily_sales = df.groupby('date')['total_amount'].sum().reset_index()
            
            fig = px.line(daily_sales, x='date', y='total_amount',
                         title='Daily Sales Trend',
                         labels={'total_amount': 'Sales (KES)', 'date': 'Date'})
            st.plotly_chart(fig, use_container_width=True)
    
    with tab2:
        low_stock = db.get_low_stock_items()
        
        st.write(f"**Low Stock Items: {len(low_stock)}**")
        
        if low_stock:
            df = pd.DataFrame(low_stock)
            st.dataframe(df[['name', 'quantity', 'reorder_level', 'unit_price']], use_container_width=True)
        else:
            st.success("All items are adequately stocked!")
        
        all_items = db.get_all_inventory()
        if all_items:
            df = pd.DataFrame(all_items)
            category_stock = df.groupby('category')['quantity'].sum().reset_index()
            
            fig = px.pie(category_stock, values='quantity', names='category',
                        title='Stock Distribution by Category')
            st.plotly_chart(fig, use_container_width=True)
    
    with tab3:
        customers = db.get_all_customers()
        if customers:
            df = pd.DataFrame(customers)
            
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Total Customers", len(customers))
            with col2:
                total_outstanding = df['outstanding_balance'].sum()
                st.metric("Total Outstanding", f"KES {total_outstanding:,.2f}")
            
            credit_customers = df[df['outstanding_balance'] > 0]
            if not credit_customers.empty:
                fig = px.bar(credit_customers.head(10), x='full_name', y='outstanding_balance',
                           title='Top 10 Customers with Outstanding Balance',
                           labels={'outstanding_balance': 'Balance (KES)', 'full_name': 'Customer'})
                st.plotly_chart(fig, use_container_width=True)

def show_admin_chat():
    st.subheader("💬 AI Assistant Chat")
    
    st.info("Chat with our AI assistant about medications, health queries, and pharmacy services")
    
    messages = db.get_chat_messages(st.session_state.user['id'], is_admin=True)
    
    for msg in messages:
        if msg['sender_id'] == st.session_state.user['id']:
            st.chat_message("user").write(msg['message'])
        else:
            st.chat_message("assistant").write(msg['message'])
    
    user_input = st.chat_input("Ask anything about medications or health...")
    
    if user_input:
        db.send_chat_message(st.session_state.user['id'], None, user_input, is_admin_chat=True)
        
        with st.spinner("Getting AI response..."):
            ai_response = get_ai_response(user_input)
            db.send_chat_message(0, st.session_state.user['id'], ai_response, is_admin_chat=True)
        
        st.rerun()

def employee_dashboard():
    st.title(f"👨‍⚕️ {st.session_state.pharmacy_name or 'Employee Dashboard'}")
    
    selected = option_menu(
        menu_title=None,
        options=["Inventory", "Sales", "Customers", "AI Chat"],
        icons=["box-seam", "cart", "people", "robot"],
        menu_icon="cast",
        default_index=0,
        orientation="horizontal"
    )
    
    if selected == "Inventory":
        show_inventory_management()
    elif selected == "Sales":
        show_sales_module()
    elif selected == "Customers":
        show_customer_management()
    elif selected == "AI Chat":
        show_admin_chat()

def customer_portal():
    st.title(f"👤 {st.session_state.pharmacy_name or 'Customer Portal'}")
    
    customer = db.get_customer_by_user_id(st.session_state.user['id'])
    
    if not customer:
        st.error("Customer profile not found")
        return
    
    selected = option_menu(
        menu_title=None,
        options=["My Account", "Purchase History", "Credit Transactions", "Payments", "Complaints", "AI Chat"],
        icons=["person", "bag", "receipt", "credit-card", "chat-left-text", "robot"],
        menu_icon="cast",
        default_index=0,
        orientation="horizontal"
    )
    
    if selected == "My Account":
        st.subheader("📋 Account Status")
        
        col1, col2 = st.columns(2)
        with col1:
            st.write(f"**Customer Code:** {customer['customer_code']}")
            st.write(f"**Name:** {customer['full_name']}")
            st.write(f"**Phone:** {customer['phone']}")
            st.write(f"**Email:** {customer['email']}")
        
        with col2:
            st.metric("Credit Limit", f"KES {customer['credit_limit']:,.2f}")
            st.metric("Outstanding Balance", f"KES {customer['outstanding_balance']:,.2f}")
            
            if customer['outstanding_balance'] > 0:
                st.warning("You have an outstanding balance. Please make a payment.")
    
    elif selected == "Purchase History":
        st.subheader("🛍️ Purchase History")
        
        sales = db.get_customer_sales(customer['id'])
        
        if sales:
            for sale in sales:
                with st.expander(f"{sale['sale_number']} - KES {sale['total_amount']:,.2f} ({sale['status']})"):
                    st.write(f"**Date:** {sale['created_at']}")
                    st.write(f"**Total Amount:** KES {sale['total_amount']:,.2f}")
                    st.write(f"**Amount Paid:** KES {sale['amount_paid']:,.2f}")
                    st.write(f"**Balance:** KES {sale['total_amount'] - sale['amount_paid']:,.2f}")
                    st.write(f"**Payment Method:** {sale['payment_method']}")
                    st.write(f"**Status:** {sale['status']}")
                    
                    items = db.get_sale_items(sale['id'])
                    if items:
                        st.write("**Items:**")
                        for item in items:
                            st.write(f"- {item['product_name']} x{item['quantity']} @ KES {item['unit_price']:,.2f} = KES {item['total_price']:,.2f}")
        else:
            st.info("No purchase history yet")
    
    elif selected == "Credit Transactions":
        st.subheader("📊 Credit Transaction History")
        
        transactions = db.get_credit_transactions(customer['id'])
        
        if transactions:
            for txn in transactions:
                txn_type_icons = {"credit_issued": "🔴", "payment": "🟢", "adjustment": "🟡"}
                icon = txn_type_icons.get(txn['transaction_type'], "⚪")
                
                with st.expander(f"{icon} {txn['transaction_type'].replace('_', ' ').title()} - KES {txn['amount']:,.2f} ({txn['created_at']})"):
                    st.write(f"**Date:** {txn['created_at']}")
                    st.write(f"**Type:** {txn['transaction_type'].replace('_', ' ').title()}")
                    st.write(f"**Amount:** KES {txn['amount']:,.2f}")
                    st.write(f"**Balance Before:** KES {txn['balance_before']:,.2f}")
                    st.write(f"**Balance After:** KES {txn['balance_after']:,.2f}")
                    if txn['sale_number']:
                        st.write(f"**Related Sale:** {txn['sale_number']}")
                    if txn['payment_method']:
                        st.write(f"**Payment Method:** {txn['payment_method']}")
                    if txn['notes']:
                        st.info(f"**Notes:** {txn['notes']}")
                    if txn['recorded_by_name']:
                        st.write(f"**Recorded By:** {txn['recorded_by_name']}")
        else:
            st.info("No credit transactions yet")
    
    elif selected == "Payments":
        st.subheader("💳 Payment History")
        
        payments = db.get_customer_payments(customer['id'])
        
        if payments:
            df = pd.DataFrame(payments)
            df['amount'] = df['amount'].apply(lambda x: f"KES {x:,.2f}")
            st.dataframe(df[['created_at', 'amount', 'payment_method', 'sale_number', 'recorded_by_name']], use_container_width=True)
        else:
            st.info("No payment history yet")
    
    elif selected == "Complaints":
        st.subheader("📝 My Complaints")
        
        tab1, tab2 = st.tabs(["Submit Complaint", "My Complaints"])
        
        with tab1:
            subject = st.text_input("Subject")
            message = st.text_area("Message")
            
            if st.button("Submit Complaint"):
                if subject and message:
                    db.create_complaint(customer['id'], subject, message)
                    st.success("Complaint submitted successfully!")
                    st.rerun()
                else:
                    st.warning("Please fill in all fields")
        
        with tab2:
            complaints = db.get_customer_complaints(customer['id'])
            
            if complaints:
                for complaint in complaints:
                    status_color = {"open": "🔴", "in_progress": "🟡", "resolved": "🟢", "closed": "⚫"}
                    with st.expander(f"{status_color[complaint['status']]} {complaint['subject']}"):
                        st.write(f"**Date:** {complaint['created_at']}")
                        st.write(f"**Status:** {complaint['status']}")
                        st.write(f"**Message:** {complaint['message']}")
                        
                        if complaint['response']:
                            st.info(f"**Response from Admin:** {complaint['response']}")
            else:
                st.info("No complaints submitted yet")
    
    elif selected == "AI Chat":
        st.subheader("💬 Chat with AI Assistant")
        
        st.info("Ask questions about medications, health advice, or pharmacy services")
        
        messages = db.get_chat_messages(st.session_state.user['id'], is_admin=False)
        
        for msg in messages:
            if msg['sender_id'] == st.session_state.user['id']:
                st.chat_message("user").write(msg['message'])
            else:
                st.chat_message("assistant").write(msg['message'])
        
        user_input = st.chat_input("Ask anything...")
        
        if user_input:
            db.send_chat_message(st.session_state.user['id'], None, user_input, is_admin_chat=True)
            
            with st.spinner("Getting AI response..."):
                ai_response = get_ai_response(user_input, f"Customer: {customer['full_name']}, Outstanding Balance: KES {customer['outstanding_balance']:,.2f}")
                db.send_chat_message(0, st.session_state.user['id'], ai_response, is_admin_chat=True)
            
            st.rerun()

def main():
    if not st.session_state.user:
        if 'page' not in st.session_state:
            st.session_state.page = 'landing'
        
        if st.session_state.page == 'landing':
            landing_page()
        elif st.session_state.page == 'login':
            login_page()
    else:
        with st.sidebar:
            st.write(f"### Welcome, {st.session_state.user['full_name']}")
            st.write(f"**Role:** {st.session_state.user['role'].title()}")
            
            if st.button("🚪 Logout", use_container_width=True):
                st.session_state.user = None
                st.session_state.cart = []
                st.session_state.page = 'landing'
                st.rerun()
        
        if st.session_state.user['role'] == 'admin':
            admin_dashboard()
        elif st.session_state.user['role'] == 'employee':
            employee_dashboard()
        elif st.session_state.user['role'] == 'customer':
            customer_portal()

if __name__ == "__main__":
    main()
