import sqlite3
import bcrypt
from datetime import datetime
import json

class Database:
    def __init__(self, db_name='pharmacy.db'):
        self.db_name = db_name
        self.init_database()
    
    def get_connection(self):
        conn = sqlite3.connect(self.db_name, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn
    
    def init_database(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS pharmacy_settings (
                id INTEGER PRIMARY KEY,
                pharmacy_name TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                full_name TEXT NOT NULL,
                email TEXT,
                phone TEXT,
                role TEXT NOT NULL CHECK(role IN ('admin', 'employee', 'customer')),
                status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'approved', 'rejected')),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS inventory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                barcode TEXT UNIQUE,
                name TEXT NOT NULL,
                description TEXT,
                category TEXT,
                quantity INTEGER DEFAULT 0,
                unit_price REAL NOT NULL,
                reorder_level INTEGER DEFAULT 10,
                supplier TEXT,
                expiry_date DATE,
                created_by INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (created_by) REFERENCES users(id)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS customers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER UNIQUE,
                customer_code TEXT UNIQUE NOT NULL,
                full_name TEXT NOT NULL,
                phone TEXT NOT NULL,
                email TEXT,
                address TEXT,
                credit_limit REAL DEFAULT 0,
                outstanding_balance REAL DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sales (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sale_number TEXT UNIQUE NOT NULL,
                customer_id INTEGER,
                total_amount REAL NOT NULL,
                amount_paid REAL DEFAULT 0,
                payment_method TEXT CHECK(payment_method IN ('Cash', 'M-Pesa', 'Bank Transfer', 'Credit')),
                status TEXT DEFAULT 'completed' CHECK(status IN ('completed', 'partial', 'credit')),
                served_by INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (customer_id) REFERENCES customers(id),
                FOREIGN KEY (served_by) REFERENCES users(id)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sale_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sale_id INTEGER NOT NULL,
                inventory_id INTEGER NOT NULL,
                product_name TEXT NOT NULL,
                quantity INTEGER NOT NULL,
                unit_price REAL NOT NULL,
                total_price REAL NOT NULL,
                FOREIGN KEY (sale_id) REFERENCES sales(id),
                FOREIGN KEY (inventory_id) REFERENCES inventory(id)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_id INTEGER NOT NULL,
                sale_id INTEGER,
                amount REAL NOT NULL,
                payment_method TEXT NOT NULL,
                reference_number TEXT,
                recorded_by INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (customer_id) REFERENCES customers(id),
                FOREIGN KEY (sale_id) REFERENCES sales(id),
                FOREIGN KEY (recorded_by) REFERENCES users(id)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS credit_transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_id INTEGER NOT NULL,
                sale_id INTEGER,
                transaction_type TEXT NOT NULL CHECK(transaction_type IN ('credit_issued', 'payment', 'adjustment')),
                amount REAL NOT NULL,
                balance_before REAL NOT NULL,
                balance_after REAL NOT NULL,
                payment_method TEXT,
                reference_number TEXT,
                notes TEXT,
                recorded_by INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (customer_id) REFERENCES customers(id),
                FOREIGN KEY (sale_id) REFERENCES sales(id),
                FOREIGN KEY (recorded_by) REFERENCES users(id)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS complaints (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_id INTEGER NOT NULL,
                subject TEXT NOT NULL,
                message TEXT NOT NULL,
                status TEXT DEFAULT 'open' CHECK(status IN ('open', 'in_progress', 'resolved', 'closed')),
                response TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (customer_id) REFERENCES customers(id)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS chat_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sender_id INTEGER NOT NULL,
                receiver_id INTEGER,
                message TEXT NOT NULL,
                is_admin_chat BOOLEAN DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (sender_id) REFERENCES users(id),
                FOREIGN KEY (receiver_id) REFERENCES users(id)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS pending_actions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                action_type TEXT NOT NULL CHECK(action_type IN ('inventory_update', 'sale_adjustment', 'payment_adjustment')),
                employee_id INTEGER NOT NULL,
                action_data TEXT NOT NULL,
                description TEXT,
                status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'approved', 'rejected')),
                reviewed_by INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                reviewed_at TIMESTAMP,
                FOREIGN KEY (employee_id) REFERENCES users(id),
                FOREIGN KEY (reviewed_by) REFERENCES users(id)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS audit_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                action TEXT NOT NULL,
                table_name TEXT,
                record_id INTEGER,
                old_value TEXT,
                new_value TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')
        
        conn.commit()
        
        cursor.execute("SELECT COUNT(*) as count FROM users WHERE role='admin'")
        admin_count = cursor.fetchone()['count']
        
        if admin_count == 0:
            password = bcrypt.hashpw("admin123".encode('utf-8'), bcrypt.gensalt())
            cursor.execute('''
                INSERT INTO users (username, password, full_name, role, status)
                VALUES (?, ?, ?, ?, ?)
            ''', ('admin', password.decode('utf-8'), 'System Administrator', 'admin', 'approved'))
            conn.commit()
        
        conn.close()
    
    def hash_password(self, password):
        return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    
    def verify_password(self, password, hashed):
        return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))
    
    def create_user(self, username, password, full_name, email, phone, role):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            hashed_password = self.hash_password(password)
            status = 'approved' if role == 'admin' else 'pending'
            
            cursor.execute('''
                INSERT INTO users (username, password, full_name, email, phone, role, status)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (username, hashed_password, full_name, email, phone, role, status))
            conn.commit()
            user_id = cursor.lastrowid
            
            if role == 'customer':
                customer_code = f"CUST{user_id:05d}"
                cursor.execute('''
                    INSERT INTO customers (user_id, customer_code, full_name, phone, email)
                    VALUES (?, ?, ?, ?, ?)
                ''', (user_id, customer_code, full_name, phone, email))
                conn.commit()
            
            conn.close()
            return True, "Registration successful! Please wait for admin approval." if status == 'pending' else "Account created successfully!"
        except sqlite3.IntegrityError:
            conn.close()
            return False, "Username already exists!"
        except Exception as e:
            conn.close()
            return False, f"Error: {str(e)}"
    
    def authenticate_user(self, username, password):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
        user = cursor.fetchone()
        conn.close()
        
        if user and self.verify_password(password, user['password']):
            if user['status'] != 'approved':
                return None, "Your account is pending approval from the administrator."
            return dict(user), None
        return None, "Invalid username or password!"
    
    def get_pharmacy_name(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT pharmacy_name FROM pharmacy_settings WHERE id = 1")
        result = cursor.fetchone()
        conn.close()
        return result['pharmacy_name'] if result else None
    
    def set_pharmacy_name(self, name):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) as count FROM pharmacy_settings")
        count = cursor.fetchone()['count']
        
        if count == 0:
            cursor.execute("INSERT INTO pharmacy_settings (id, pharmacy_name) VALUES (1, ?)", (name,))
        else:
            cursor.execute("UPDATE pharmacy_settings SET pharmacy_name = ?, updated_at = CURRENT_TIMESTAMP WHERE id = 1", (name,))
        
        conn.commit()
        conn.close()
    
    def get_pending_users(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM users 
            WHERE status = 'pending' AND role IN ('employee', 'customer')
            ORDER BY created_at DESC
        ''')
        users = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return users
    
    def approve_user(self, user_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET status = 'approved', updated_at = CURRENT_TIMESTAMP WHERE id = ?", (user_id,))
        conn.commit()
        conn.close()
    
    def reject_user(self, user_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET status = 'rejected', updated_at = CURRENT_TIMESTAMP WHERE id = ?", (user_id,))
        conn.commit()
        conn.close()
    
    def add_inventory_item(self, barcode, name, description, category, quantity, unit_price, reorder_level, supplier, expiry_date, user_id, user_role):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            if user_role == 'employee':
                action_data = {
                    'action': 'add',
                    'barcode': barcode,
                    'name': name,
                    'description': description,
                    'category': category,
                    'quantity': quantity,
                    'unit_price': unit_price,
                    'reorder_level': reorder_level,
                    'supplier': supplier,
                    'expiry_date': expiry_date
                }
                cursor.execute('''
                    INSERT INTO pending_actions (action_type, employee_id, action_data, description)
                    VALUES (?, ?, ?, ?)
                ''', ('inventory_update', user_id, json.dumps(action_data), f"Add new item: {name}"))
                conn.commit()
                conn.close()
                return True, "Request submitted for admin approval!"
            else:
                cursor.execute('''
                    INSERT INTO inventory (barcode, name, description, category, quantity, unit_price, reorder_level, supplier, expiry_date, created_by)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (barcode, name, description, category, quantity, unit_price, reorder_level, supplier, expiry_date, user_id))
                conn.commit()
                item_id = cursor.lastrowid
                
                self.log_audit(user_id, 'INSERT', 'inventory', item_id, None, json.dumps({'name': name, 'quantity': quantity}))
                
                conn.close()
                return True, "Item added successfully!"
        except sqlite3.IntegrityError:
            conn.close()
            return False, "Barcode already exists!"
        except Exception as e:
            conn.close()
            return False, f"Error: {str(e)}"
    
    def update_inventory_item(self, item_id, barcode, name, description, category, quantity, unit_price, reorder_level, supplier, expiry_date, user_id, user_role):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            if user_role == 'employee':
                cursor.execute("SELECT * FROM inventory WHERE id = ?", (item_id,))
                old_item = dict(cursor.fetchone())
                
                action_data = {
                    'action': 'update',
                    'item_id': item_id,
                    'barcode': barcode,
                    'name': name,
                    'description': description,
                    'category': category,
                    'quantity': quantity,
                    'unit_price': unit_price,
                    'reorder_level': reorder_level,
                    'supplier': supplier,
                    'expiry_date': expiry_date,
                    'old_quantity': old_item['quantity']
                }
                cursor.execute('''
                    INSERT INTO pending_actions (action_type, employee_id, action_data, description)
                    VALUES (?, ?, ?, ?)
                ''', ('inventory_update', user_id, json.dumps(action_data), f"Update item: {name} (Qty: {old_item['quantity']} -> {quantity})"))
                conn.commit()
                conn.close()
                return True, "Update request submitted for admin approval!"
            else:
                cursor.execute('''
                    UPDATE inventory 
                    SET barcode=?, name=?, description=?, category=?, quantity=?, unit_price=?, 
                        reorder_level=?, supplier=?, expiry_date=?, updated_at=CURRENT_TIMESTAMP
                    WHERE id=?
                ''', (barcode, name, description, category, quantity, unit_price, reorder_level, supplier, expiry_date, item_id))
                conn.commit()
                
                self.log_audit(user_id, 'UPDATE', 'inventory', item_id, None, json.dumps({'name': name, 'quantity': quantity}))
                
                conn.close()
                return True, "Item updated successfully!"
        except Exception as e:
            conn.close()
            return False, f"Error: {str(e)}"
    
    def search_inventory(self, search_term):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM inventory 
            WHERE name LIKE ? OR barcode LIKE ? OR category LIKE ?
            ORDER BY name
        ''', (f'%{search_term}%', f'%{search_term}%', f'%{search_term}%'))
        items = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return items
    
    def get_all_inventory(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM inventory ORDER BY name")
        items = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return items
    
    def get_inventory_by_barcode(self, barcode):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM inventory WHERE barcode = ?", (barcode,))
        item = cursor.fetchone()
        conn.close()
        return dict(item) if item else None
    
    def create_sale(self, customer_id, items, total_amount, amount_paid, payment_method, user_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            sale_number = f"SALE{datetime.now().strftime('%Y%m%d%H%M%S')}"
            balance = total_amount - amount_paid
            status = 'completed' if balance == 0 else ('partial' if amount_paid > 0 else 'credit')
            
            cursor.execute('''
                INSERT INTO sales (sale_number, customer_id, total_amount, amount_paid, payment_method, status, served_by)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (sale_number, customer_id, total_amount, amount_paid, payment_method, status, user_id))
            sale_id = cursor.lastrowid
            
            for item in items:
                cursor.execute('''
                    INSERT INTO sale_items (sale_id, inventory_id, product_name, quantity, unit_price, total_price)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (sale_id, item['id'], item['name'], item['quantity'], item['unit_price'], item['total']))
                
                cursor.execute('''
                    UPDATE inventory SET quantity = quantity - ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ''', (item['quantity'], item['id']))
            
            if customer_id:
                cursor.execute("SELECT outstanding_balance FROM customers WHERE id = ?", (customer_id,))
                old_balance = cursor.fetchone()['outstanding_balance']
                
                if balance > 0:
                    new_balance = old_balance + balance
                    
                    cursor.execute('''
                        UPDATE customers SET outstanding_balance = ?
                        WHERE id = ?
                    ''', (new_balance, customer_id))
                    
                    cursor.execute('''
                        INSERT INTO credit_transactions (customer_id, sale_id, transaction_type, amount, balance_before, balance_after, recorded_by, notes)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (customer_id, sale_id, 'credit_issued', balance, old_balance, new_balance, user_id, f"Credit issued from sale {sale_number}"))
                
                if amount_paid > 0:
                    cursor.execute('''
                        INSERT INTO payments (customer_id, sale_id, amount, payment_method, recorded_by)
                        VALUES (?, ?, ?, ?, ?)
                    ''', (customer_id, sale_id, amount_paid, payment_method, user_id))
                    
                    cursor.execute("SELECT outstanding_balance FROM customers WHERE id = ?", (customer_id,))
                    current_balance = cursor.fetchone()['outstanding_balance']
                    
                    cursor.execute('''
                        INSERT INTO credit_transactions (customer_id, sale_id, transaction_type, amount, balance_before, balance_after, payment_method, recorded_by, notes)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (customer_id, sale_id, 'payment', amount_paid, old_balance, current_balance, payment_method, user_id, f"Payment for sale {sale_number}"))
            
            conn.commit()
            conn.close()
            return True, sale_number, sale_id
        except Exception as e:
            conn.close()
            return False, str(e), None
    
    def get_all_customers(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM customers ORDER BY full_name")
        customers = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return customers
    
    def get_customer_by_user_id(self, user_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM customers WHERE user_id = ?", (user_id,))
        customer = cursor.fetchone()
        conn.close()
        return dict(customer) if customer else None
    
    def get_customer_sales(self, customer_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT s.*, u.full_name as served_by_name
            FROM sales s
            LEFT JOIN users u ON s.served_by = u.id
            WHERE s.customer_id = ?
            ORDER BY s.created_at DESC
        ''', (customer_id,))
        sales = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return sales
    
    def get_customer_payments(self, customer_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT p.*, s.sale_number, u.full_name as recorded_by_name
            FROM payments p
            LEFT JOIN sales s ON p.sale_id = s.id
            LEFT JOIN users u ON p.recorded_by = u.id
            WHERE p.customer_id = ?
            ORDER BY p.created_at DESC
        ''', (customer_id,))
        payments = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return payments
    
    def record_payment(self, customer_id, sale_id, amount, payment_method, user_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT outstanding_balance FROM customers WHERE id = ?", (customer_id,))
            old_balance = cursor.fetchone()['outstanding_balance']
            new_balance = old_balance - amount
            
            cursor.execute('''
                INSERT INTO payments (customer_id, sale_id, amount, payment_method, recorded_by)
                VALUES (?, ?, ?, ?, ?)
            ''', (customer_id, sale_id, amount, payment_method, user_id))
            
            cursor.execute('''
                UPDATE customers SET outstanding_balance = ?
                WHERE id = ?
            ''', (new_balance, customer_id))
            
            cursor.execute('''
                INSERT INTO credit_transactions (customer_id, sale_id, transaction_type, amount, balance_before, balance_after, payment_method, recorded_by, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (customer_id, sale_id, 'payment', amount, old_balance, new_balance, payment_method, user_id, f"Payment of KES {amount:,.2f}"))
            
            if sale_id:
                cursor.execute('''
                    UPDATE sales SET amount_paid = amount_paid + ?
                    WHERE id = ?
                ''', (amount, sale_id))
                
                cursor.execute("SELECT total_amount, amount_paid, sale_number FROM sales WHERE id = ?", (sale_id,))
                sale = cursor.fetchone()
                if sale:
                    balance = sale['total_amount'] - sale['amount_paid']
                    new_status = 'completed' if balance == 0 else 'partial'
                    cursor.execute("UPDATE sales SET status = ? WHERE id = ?", (new_status, sale_id))
            
            conn.commit()
            conn.close()
            return True, "Payment recorded successfully!"
        except Exception as e:
            conn.close()
            return False, f"Error: {str(e)}"
    
    def create_complaint(self, customer_id, subject, message):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO complaints (customer_id, subject, message)
            VALUES (?, ?, ?)
        ''', (customer_id, subject, message))
        conn.commit()
        conn.close()
        return True
    
    def get_customer_complaints(self, customer_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM complaints WHERE customer_id = ?
            ORDER BY created_at DESC
        ''', (customer_id,))
        complaints = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return complaints
    
    def get_all_complaints(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT c.*, cu.full_name as customer_name, cu.customer_code
            FROM complaints c
            LEFT JOIN customers cu ON c.customer_id = cu.id
            ORDER BY c.created_at DESC
        ''')
        complaints = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return complaints
    
    def update_complaint(self, complaint_id, status, response):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE complaints 
            SET status = ?, response = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (status, response, complaint_id))
        conn.commit()
        conn.close()
    
    def send_chat_message(self, sender_id, receiver_id, message, is_admin_chat=False):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO chat_messages (sender_id, receiver_id, message, is_admin_chat)
            VALUES (?, ?, ?, ?)
        ''', (sender_id, receiver_id, message, is_admin_chat))
        conn.commit()
        conn.close()
    
    def get_chat_messages(self, user_id, is_admin=False):
        conn = self.get_connection()
        cursor = conn.cursor()
        if is_admin:
            cursor.execute('''
                SELECT cm.*, u.full_name as sender_name
                FROM chat_messages cm
                LEFT JOIN users u ON cm.sender_id = u.id
                WHERE cm.is_admin_chat = 1
                ORDER BY cm.created_at ASC
            ''')
        else:
            cursor.execute('''
                SELECT cm.*, u.full_name as sender_name
                FROM chat_messages cm
                LEFT JOIN users u ON cm.sender_id = u.id
                WHERE (cm.sender_id = ? OR cm.receiver_id = ?) AND cm.is_admin_chat = 1
                ORDER BY cm.created_at ASC
            ''', (user_id, user_id))
        messages = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return messages
    
    def create_pending_action(self, action_type, employee_id, action_data, description):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO pending_actions (action_type, employee_id, action_data, description)
            VALUES (?, ?, ?, ?)
        ''', (action_type, employee_id, json.dumps(action_data), description))
        conn.commit()
        action_id = cursor.lastrowid
        conn.close()
        return action_id
    
    def get_pending_actions(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT pa.*, u.full_name as employee_name
            FROM pending_actions pa
            LEFT JOIN users u ON pa.employee_id = u.id
            WHERE pa.status = 'pending'
            ORDER BY pa.created_at DESC
        ''')
        actions = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return actions
    
    def approve_action(self, action_id, admin_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM pending_actions WHERE id = ?", (action_id,))
        action = cursor.fetchone()
        
        if action:
            action_data = json.loads(action['action_data'])
            
            if action['action_type'] == 'inventory_update':
                if action_data.get('action') == 'add':
                    cursor.execute('''
                        INSERT INTO inventory (barcode, name, description, category, quantity, unit_price, reorder_level, supplier, expiry_date, created_by)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (action_data['barcode'], action_data['name'], action_data['description'], action_data['category'], 
                          action_data['quantity'], action_data['unit_price'], action_data['reorder_level'], 
                          action_data['supplier'], action_data['expiry_date'], action['employee_id']))
                    item_id = cursor.lastrowid
                    self.log_audit(action['employee_id'], 'INSERT', 'inventory', item_id, None, json.dumps({'name': action_data['name'], 'quantity': action_data['quantity']}))
                
                elif action_data.get('action') == 'update':
                    cursor.execute('''
                        UPDATE inventory 
                        SET barcode=?, name=?, description=?, category=?, quantity=?, unit_price=?, 
                            reorder_level=?, supplier=?, expiry_date=?, updated_at=CURRENT_TIMESTAMP
                        WHERE id=?
                    ''', (action_data['barcode'], action_data['name'], action_data['description'], action_data['category'],
                          action_data['quantity'], action_data['unit_price'], action_data['reorder_level'],
                          action_data['supplier'], action_data['expiry_date'], action_data['item_id']))
                    self.log_audit(action['employee_id'], 'UPDATE', 'inventory', action_data['item_id'], 
                                 json.dumps({'quantity': action_data['old_quantity']}), 
                                 json.dumps({'quantity': action_data['quantity']}))
            
            cursor.execute('''
                UPDATE pending_actions 
                SET status = 'approved', reviewed_by = ?, reviewed_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ''', (admin_id, action_id))
            
            conn.commit()
        conn.close()
    
    def reject_action(self, action_id, admin_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE pending_actions 
            SET status = 'rejected', reviewed_by = ?, reviewed_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (admin_id, action_id))
        conn.commit()
        conn.close()
    
    def log_audit(self, user_id, action, table_name, record_id, old_value, new_value):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO audit_logs (user_id, action, table_name, record_id, old_value, new_value)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (user_id, action, table_name, record_id, old_value, new_value))
        conn.commit()
        conn.close()
    
    def get_sales_summary(self, start_date=None, end_date=None):
        conn = self.get_connection()
        cursor = conn.cursor()
        query = "SELECT COUNT(*) as count, SUM(total_amount) as total FROM sales"
        if start_date and end_date:
            query += f" WHERE DATE(created_at) BETWEEN '{start_date}' AND '{end_date}'"
        cursor.execute(query)
        summary = dict(cursor.fetchone())
        conn.close()
        return summary
    
    def get_low_stock_items(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM inventory 
            WHERE quantity <= reorder_level
            ORDER BY quantity ASC
        ''')
        items = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return items
    
    def get_all_sales(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT s.*, c.full_name as customer_name, c.customer_code, u.full_name as served_by_name
            FROM sales s
            LEFT JOIN customers c ON s.customer_id = c.id
            LEFT JOIN users u ON s.served_by = u.id
            ORDER BY s.created_at DESC
        ''')
        sales = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return sales
    
    def get_sale_items(self, sale_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM sale_items WHERE sale_id = ?", (sale_id,))
        items = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return items
    
    def get_credit_transactions(self, customer_id):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT ct.*, s.sale_number, u.full_name as recorded_by_name
            FROM credit_transactions ct
            LEFT JOIN sales s ON ct.sale_id = s.id
            LEFT JOIN users u ON ct.recorded_by = u.id
            WHERE ct.customer_id = ?
            ORDER BY ct.created_at DESC
        ''', (customer_id,))
        transactions = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return transactions
