# 💊 Pharmacy Management System - Kenya

A comprehensive, production-ready pharmacy management system designed for Kenyan chemists and pharmacies. Built with Python and Streamlit.

## 🌟 Features

### Multi-Role Authentication System
- **Admin/Chemist Owner**: Full system control with custom pharmacy name setup
- **Employees**: Require admin approval before access, role-based permissions
- **Customers**: Self-registration with account portal access

### Inventory Management
- Manual entry of products
- Barcode scanning via mobile phone camera or computer webcam
- Real-time search with autocomplete
- Low stock alerts and reorder level tracking
- Category-based organization

### Sales Module
- Point of sale (POS) system with shopping cart
- Multiple payment methods: Cash, M-Pesa, Bank Transfer, Credit
- Credit sales tracking
- Receipt generation with sale numbers
- Walk-in and registered customer sales

### Customer Management & CRM
- Customer profiles with credit limits
- Purchase history tracking
- Payment history and outstanding balance monitoring
- Complaint management system
- Customer analytics and reporting

### Customer Portal (View-Only)
- Account status overview
- Credit history and outstanding balances
- Payment records
- Complaint submission and tracking
- AI chat support

### Employee Action Tracking
- All employee adjustments require admin approval
- Pending actions notification system
- Password-protected action deletion
- Audit trail for all changes

### AI Chat Assistant (Cohere)
- Context-aware responses
- Medication and health advice
- Customer support automation
- Available for both customers and admin

### Reports & Analytics
- Sales reports with date filtering
- Inventory reports with low stock alerts
- Customer analytics and outstanding balances
- Interactive charts and visualizations
- Daily sales trends

### Kenyan-Specific Features
- Currency in Kenyan Shillings (KES)
- M-Pesa payment option
- Local business practices support

## 🚀 Setup Instructions

### Prerequisites
- Python 3.11+
- Replit environment (or local setup)

### Installation

1. **Environment Variables**
   Create a `.env` file or add to Replit Secrets:
   ```
   COHERE_API_KEY=your_cohere_api_key_here
   ```

2. **Get Cohere API Key**
   - Visit [https://cohere.com/](https://cohere.com/)
   - Sign up for a free account
   - Navigate to API Keys section
   - Copy your API key
   - Add it to your environment variables

3. **Database Setup**
   The SQLite database will be automatically created on first run with:
   - Default admin account
   - All required tables
   - Proper schema and relationships

4. **Run the Application**
   ```bash
   streamlit run app.py --server.port 5000
   ```

## 📝 Default Login Credentials

**Admin Account:**
- Username: `admin`
- Password: `admin123`

⚠️ **Important**: Change the admin password immediately after first login!

## 🎯 First-Time Setup (Admin)

1. Login with default admin credentials
2. Navigate to **Pharmacy Settings**
3. Set your pharmacy name (e.g., "Nibel Chemist")
4. This name will display throughout the system and on employee registration

## 👥 User Roles & Permissions

### Admin/Chemist Owner
- Configure pharmacy name
- Approve/reject employee and customer registrations
- Full inventory management
- Sales processing
- Customer management and payments
- CRM and complaint handling
- Review and approve employee actions
- Access all reports and analytics
- AI chat support

### Employee
- Inventory management (requires admin approval for adjustments)
- Sales processing
- Customer service
- Limited customer management
- AI chat support
- **Note**: Account requires admin approval before access

### Customer
- View-only account status
- Credit history viewing
- Payment records viewing
- Submit complaints
- Chat with admin
- AI assistant support
- **Note**: Cannot modify balances or payment records

## 📱 Barcode Scanning

### Mobile Phone
1. Navigate to Inventory > Scan Barcode tab
2. Click "Take Photo"
3. Use your mobile camera to scan product barcodes
4. System automatically detects and searches for products

### Computer Webcam
1. Same process as mobile
2. Use computer's built-in webcam
3. Ensure good lighting for accurate scanning

## 💰 Payment Methods

1. **Cash**: Direct cash payments
2. **M-Pesa**: Kenya's mobile money platform
3. **Bank Transfer**: Bank-to-bank transfers
4. **Credit**: Buy now, pay later for registered customers

## 🔔 Employee Action Workflow

1. Employee makes inventory adjustment
2. Action saved as "pending"
3. Admin receives notification
4. Admin reviews and can:
   - **Approve**: Changes take effect immediately
   - **Delete**: Requires admin password confirmation

## 📊 Reports Available

### Sales Reports
- Total sales by date range
- Transaction count
- Daily sales trends
- Payment method breakdown

### Inventory Reports
- Current stock levels
- Low stock alerts
- Category-wise distribution
- Reorder recommendations

### Customer Reports
- Total customers
- Outstanding balances
- Top customers by credit
- Payment patterns

## 🛡️ Security Features

- Bcrypt password hashing
- Role-based access control
- Session management
- Password-protected critical actions
- Audit logging for all changes
- Status-based user approval system

## 📂 Database Schema

The system uses SQLite with the following main tables:
- `pharmacy_settings`: Pharmacy configuration
- `users`: User authentication and profiles
- `inventory`: Product catalog
- `customers`: Customer information
- `sales`: Sales transactions
- `sale_items`: Sale line items
- `payments`: Payment records
- `complaints`: Customer complaints
- `chat_messages`: Chat history
- `pending_actions`: Employee action queue
- `audit_logs`: System audit trail

## 🤖 AI Chat Features

The Cohere-powered AI assistant can help with:
- Medication information and usage
- General health advice
- Pharmacy service inquiries
- Product recommendations
- Common health questions

## 📱 Mobile Responsiveness

The system is fully responsive and works on:
- Desktop computers
- Tablets
- Mobile phones
- All modern web browsers

## 🔧 Troubleshooting

### AI Chat Not Working
- Ensure COHERE_API_KEY is set in environment variables
- Check API key validity at cohere.com
- Verify internet connection

### Barcode Scanner Not Working
- Allow camera permissions in browser
- Ensure good lighting
- Try cleaning camera lens
- Check barcode quality and format

### Employee Cannot Login
- Check if admin has approved the account
- Verify username and password
- Contact admin for account status

## 📈 Scaling & Production

For production deployment:
1. Change default admin password
2. Set up regular database backups
3. Configure proper HTTPS/SSL
4. Monitor API usage (Cohere)
5. Set appropriate credit limits
6. Train staff on system usage

## 💡 Tips for Best Use

1. **Regular Stock Updates**: Keep inventory current for accurate reporting
2. **Customer Registration**: Encourage customers to register for credit facilities
3. **Daily Reconciliation**: Review sales and payments daily
4. **Respond to Complaints**: Address customer issues promptly
5. **Monitor Low Stock**: Act on reorder alerts to prevent stockouts
6. **Review Employee Actions**: Regularly check and approve pending actions

## 🆘 Support

For issues or questions:
1. Use the AI chat assistant for immediate help
2. Submit complaints through the customer portal
3. Contact system administrator

## 📄 License

This system is ready for commercial use and sale to pharmacy clients.

---

**Built with ❤️ for Kenyan Pharmacies**
